<?php
require_once 'C:\wamp64\www\parap\entities\produit.php';
require_once 'C:\wamp64\www\parap\core\produitC.php';



  $id=$_POST["id"];
  $nom=$_POST["nom"];
  $prix=$_POST["prix"];
  $quantite=$_POST["quantite"];

 $produitC=new produitC();
 $produitC->modifierproduit($id,$nom,$prix,$quantite);
 header('location:index2.php');





  //affichage des résultats, pour savoir si la modification a marchée:
  // if($requete)
  // {
  //   echo("La modification à été correctement effectuée") ;
  // }
  // else
  // {
  //   echo("La modification à échouée") ;
  // }
?>
