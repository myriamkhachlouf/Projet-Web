
 <?php
require_once "C:\wamp64\www\parap\config.php";
class produitC
 {
	function ajoutproduit($produit)
	{
		$sql="insert into produit (nom,prix,quantite) values
		(:nom,:prix,:quantite)";
		$db = config::getConnexion();
		try
		{
        $req=$db->prepare($sql);


        $nom=$produit->getnom();
        $prix=$produit->getprix();
        $quantite=$produit->getquantite();


		$req->bindValue(':nom',$nom);
		$req->bindValue(':prix',$prix);
		$req->bindValue(':quantite',$quantite);




            $req->execute();

        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }

	}

	public	function afficherproduit()
	{
		//$sql="SElECT * From client inner join formationphp.client a on e.id= a.id";
		$sql="SElECT * From produit";
		$db = config::getConnexion();
		try
		{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
	}
	public function supprimerproduit($id)
	{
		$sql="DELETE FROM produit where id= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
  function modifierproduit($id,$nom,$prix,$quantite)
      {
          $sql= "UPDATE `produit` SET `nom` = '".$nom."',`prix` = '".$prix."',`quantite` = '".$quantite."' WHERE `produit`.`id` = ".$id.";";
          $db = config::getConnexion();
          try
          {
              $db->query($sql);
          }
          catch (Exception $e)
          {
              die('Erreur: '.$e->getMessage());
          }
      }
/* function modifierclient($id,$nom,$prenom,$username,$adresse,$telephone,$email,$password)
	{
		$db = config::getConnexion();
		$sql="UPDATE client SET nom='".$nom."',prenom='".$prenom."',email='".$email."',username='".$username."',adresse='".$adresse."',telephone='".$telephone."',password='".$password."',  where id='".$id."';";
		try
		{
        $req=$db->prepare($sql);

            $req->execute();

        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }

	}*/
  function trier(){
		$sql="SELECT * from produit order by date_crea desc";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
	}
  function getAllproduits($keywords){
		$sql="SELECT * FROM client WHERE CONCAT(`id`,`nom`,`prix`,`quantite`) LIKE '%".$keywords."%'";
		$db = config::getConnexion();
		try{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e){
            die('Erreur: '.$e->getMessage());
        }
    }


}
?>
