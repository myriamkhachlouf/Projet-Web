<?php
require_once 'C:\wamp64\www\parap\entities\categorie.php';
require_once 'C:\wamp64\www\parap\core\categorieC.php';



  $idCategorie=$_POST["idCategorie"];
  $nomCategorie=$_POST["nomCategorie"];

 $categorieC=new categorieC();
 $categorieC->modifiercategorie($idCategorie,$nomCategorie);
 header('location:index4.php');





  //affichage des résultats, pour savoir si la modification a marchée:
  // if($requete)
  // {
  //   echo("La modification à été correctement effectuée") ;
  // }
  // else
  // {
  //   echo("La modification à échouée") ;
  // }
?>
