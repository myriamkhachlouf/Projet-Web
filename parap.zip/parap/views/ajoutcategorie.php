<?PHP
require_once 'C:\wamp64\www\parap\entities\categorie.php';
require_once 'C:\wamp64\www\parap\core\categorieC.php';

if (isset($_POST['nomCategorie']))
{
	$categorie1=new categorie($_POST['nomCategorie'],"categorie");
	$categorieC=new categorieC();
	$categorieC->ajoutcategorie($categorie1);
	header('location:index4.php' );
}
else
{
	echo "vérifier les champs";
}
//*/

?>
