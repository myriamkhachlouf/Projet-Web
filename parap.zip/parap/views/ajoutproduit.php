<?PHP
require_once 'C:\wamp64\www\parap\entities\produit.php';
require_once 'C:\wamp64\www\parap\core\produitC.php';

if (isset($_POST['nom']) and isset($_POST['prix']) and isset($_POST['quantite']) and isset($_POST['img']))
{
	$produit1=new produit($_POST['nom'],$_POST['prix'],$_POST['quantite'],$_POST['img'],"produit");
	$produitC=new produitC();
	$produitC->ajoutproduit($produit1);
	header('location:index2.php' );
}
else
{
	echo "vérifier les champs";
}
//*/

?>
