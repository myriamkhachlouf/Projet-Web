 <?php
require_once "C:\wamp64\www\parap\config.php";
class categorieC
 {
	function ajoutcategorie($categorie)
	{
		$sql="insert into categorie (nomCategorie) values
		(:nomCategorie)";
		$db = config::getConnexion();
		try
		{
        $req=$db->prepare($sql);


        $nomCategorie=$categorie->getNomCategorie();



		$req->bindValue(':nomCategorie',$nomCategorie);



            $req->execute();

        }
        catch (Exception $e){
            echo 'Erreur: '.$e->getMessage();
        }

	}

	public	function affichercategorie()
	{
		//$sql="SElECT * From client inner join formationphp.client a on e.id= a.id";
		$sql="SElECT * From categorie";
		$db = config::getConnexion();
		try
		{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
	}

	public function supprimercategorie($id)
	{
		$sql="DELETE FROM categorie where idCategorie= :id";
		$db = config::getConnexion();
        $req=$db->prepare($sql);
		$req->bindValue(':id',$id);
		try{
            $req->execute();
           // header('Location: index.php');
        }
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
	}

  function modifiercategorie($idCategorie,$nomCategorie)
      {
          $sql= "UPDATE `categorie` SET `nomCategorie` = '".$nomCategorie."' WHERE `categorie`.`idCategorie` = ".$idCategorie.";";
          $db = config::getConnexion();
          try
          {
              $db->query($sql);
          }
          catch (Exception $e)
          {
              die('Erreur: '.$e->getMessage());
          }
      }
    }
?>
