<?PHP
require_once "C:\wamp64\www\parap\config.php";
class produit{
	private $id;
	private $nom;
	private $prix;
	private $quantite;
	private $img;

	public function __construct($nom,$prix,$quantite,$img){

		$this->nom=$nom;
		$this->prix=$prix;
		$this->quantite=$quantite;
		$this->img=$img;

	}
	 function getnom(){
		return $this->nom;
	}
	 function getprix(){
		return $this->prix;
	}
	 function getquantite(){
		return $this->quantite;
	}
	function getimg(){
	 return $this->img;
 }
	 function setid($id){
		$this->id=$id;
	}
	 function setnom($nom){
		$this->nom=$nom;
	}
	 function setprix($prix){
		$this->prix=$prix;
	}
	 function setquantite($quantite){
		$this->quantite=$quantite;
	}
	function setimg($img){
	 $this->img=$img;
 }

	 function afficherproduit()
	{
		//$sql="SElECT * From client inner join formationphp.client a on e.id= a.id";
		$sql="SElECT * From produit";
		$db = config::getConnexion();
		try
		{
		$liste=$db->query($sql);
		return $liste;
		}
        catch (Exception $e)
        {
            die('Erreur: '.$e->getMessage());
        }
	}

}


?>
