<?php
require_once "C:\wamp64\www\parap\config.php";
    class categorie{
        private $idCategorie;
        private $nomCategorie;

        function __construct($idCategorie, $nomCategorie){
            $this->idCategorie = $idCategorie;
            $this->nomCategorie = $nomCategorie;
        }

        function setIdCategorie(){
            $this->idCategorie = $idCategorie;
        }

        function getIdCategorie(){
            return $this->idCategorie;
        }

        function setNomCategorie(){
            $this->nomCategorie = $nomCategorie;
        }

        function getNomCategorie(){
            return $this->nomCategorie;
        }
        function affichercategorie()
     	{
     		//$sql="SElECT * From client inner join formationphp.client a on e.id= a.id";
     		$sql="SElECT * From categorie";
     		$db = config::getConnexion();
     		try
     		{
     		$liste=$db->query($sql);
     		return $liste;
     		}
             catch (Exception $e)
             {
                 die('Erreur: '.$e->getMessage());
             }
     	}

     
    }
?>
